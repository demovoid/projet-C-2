var searchData=
[
  ['sdijkstranode_47',['sDijkstraNode',['../structs_dijkstra_node.html',1,'']]],
  ['setnodedata_48',['SetNodeData',['../graph_8c.html#a8f38b50ad57d08302225b45b4bffa105',1,'SetNodeData(node *n, void *data):&#160;graph.c'],['../graph_8h.html#a8f38b50ad57d08302225b45b4bffa105',1,'SetNodeData(node *n, void *data):&#160;graph.c']]],
  ['sgraph_49',['sGraph',['../structs_graph.html',1,'']]],
  ['snode_50',['sNode',['../structs_node.html',1,'']]]
];
